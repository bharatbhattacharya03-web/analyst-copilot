# Analyst Copilot

An AI chat assistant + resume match scorer + LinkedIn job search launcher, built for Business Analyst, Data Analyst, and Risk Analyst job seekers.

Note on LinkedIn: LinkedIn does not allow scraping or automated search access without an official data partnership. This app does **not** scrape LinkedIn — instead it builds correct, direct LinkedIn job-search URLs (role, location, remote filter) and opens them in a new tab, which is fully within LinkedIn's normal usage.

## Features

- **Job search launcher** — pick Business Analyst / Data Analyst / Risk Analyst, add a location and remote filter, and open a live LinkedIn search in one tap.
- **Resume match score** — upload a PDF resume, pick a target role (optionally paste a job description), get an AI-generated 0–100 fit score with strengths, gaps, and keywords to add.
- **Chat** — ask career, resume, or interview-prep questions specific to analyst roles.
- Mobile-friendly, single Node.js service, ready to deploy on Render's free tier.

## Project structure

```
analyst-copilot/
  server.js          Express server (chat + resume-score APIs, serves the frontend)
  package.json
  render.yaml         Render deployment blueprint
  .env.example
  public/
    index.html
    style.css
    app.js
```

## 1. Run locally

Requires Node.js 18+.

```bash
cd analyst-copilot
npm install
cp .env.example .env
# edit .env and paste your real OpenAI API key
npm start
```

Open http://localhost:3000

## 2. Get an OpenAI API key

1. Go to https://platform.openai.com/api-keys
2. Create a new key
3. Add a small amount of billing credit (this app uses `gpt-4o-mini` by default — very cheap per request)

## 3. Deploy to Render (free, shareable live URL)

1. Push this folder to a new GitHub repository.
2. Go to https://render.com → **New +** → **Web Service** → connect your repo.
3. Render should auto-detect `render.yaml`. If not, set manually:
   - **Build command:** `npm install`
   - **Start command:** `npm start`
4. Under **Environment**, add:
   - `OPENAI_API_KEY` = your key from step 2
   - `OPENAI_MODEL` = `gpt-4o-mini` (optional, this is the default)
5. Click **Create Web Service**. First deploy takes 2–5 minutes.
6. Render gives you a URL like `https://analyst-copilot.onrender.com` — share that with friends. Anyone with the link can use it; your API key stays private on the server.

### Notes on Render's free tier
- Free web services spin down after ~15 minutes of no traffic and take ~30–60 seconds to wake back up on the next request — that's normal, not a bug.
- Uploaded resumes are processed in memory and are **not** saved to disk or a database.

## Costs / usage

Every chat message and resume score calls the OpenAI API and costs a small fraction of a cent with `gpt-4o-mini`. Watch usage at https://platform.openai.com/usage if sharing widely.

## Customizing

- Add more role tracks: edit the `.role-card` buttons in `public/index.html` and the `tickerData` array in `public/app.js`.
- Swap the AI model: change `OPENAI_MODEL` in your environment.
- Change styling: colors and fonts are defined as CSS variables at the top of `public/style.css`.
